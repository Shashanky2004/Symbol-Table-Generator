


#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
void main(){
    int i=0,j=0,x=0,n;
    void *p, *add[5];
    char ch, c, b[15], d[15];
    
    
    
    printf("enter the expression(ENDS WITH $)");
    while ((c=getchar())!='$'){       //input of expression
        b[i]=c;
        i++;
    }
    n=i-1;   //length of the digits
    
    
    printf("\ngiven expressiion ");    //printing the expression
    i=0;
    while (i<=n){
        printf("%c",b[i]);
        i++;
    }
    
    printf("\n--------SYMBOL TABLE--------\n");
    printf("SYMBOL \t Address \t TYPE");
    while(j<=n){
        c=b[j];
        if(isalpha(toascii(c))){
            p=malloc(c);
            add[x]=p;
            d[x]=c;
            printf("\n%c \t %p \t identifier \n",c,p);
            x++;
            j++;
        }
        
        else {
            ch=c;
            if(ch=='+' || ch=='-'){
                p=malloc(ch);
                add[x]=p;
                d[x]=ch;
                printf("\n%c \t %p \t operator \n",ch,p);
                x++;
                j++;
                
            }
        }
        
    }
    
    
}
